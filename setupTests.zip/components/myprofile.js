import React  from 'react';
export default function MyProfile(){
        return(
           <div>
               <h1>MyProfile</h1>
             
           </div>
        );
    
}