import React  from 'react';
export default function ViewPosts(){
        return(
           <div>
               <h1>ViewPosts</h1>
              
           </div>
        );
    
}