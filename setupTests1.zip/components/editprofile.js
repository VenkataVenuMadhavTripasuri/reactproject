import React  from 'react';
export default function EditProfile(){
        return(
           <div>
               <h1>EditProfile</h1>
               
           </div>
        );
    
}